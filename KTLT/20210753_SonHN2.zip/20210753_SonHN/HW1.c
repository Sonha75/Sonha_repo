#include <stdio.h>
#include <stdint.h>

void main(){
    int a=3;
    int b=a>>1;
    printf('%c', b);
}