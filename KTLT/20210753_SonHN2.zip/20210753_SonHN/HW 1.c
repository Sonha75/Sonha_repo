
#include <stdio.h>

void printBinary(int num, int bit)
{
    int sobit;
    for (sobit = bit - 1; sobit >= 0; sobit--) // dịch bit r so sánh để return ra  num dạng binary
    {

        if ((num >> sobit) & 1) // num & 0000 0001 =0|1
            printf("1");
        else
            printf("0");
    }
}
typedef union
{
    float f;
    struct
    {
        unsigned int mantissa : 23; // phần m 23 bit
        unsigned int exponent : 8;  // phần mũ 8 bit
        unsigned int sign : 1;   //phần dấu 1 bit
    } component;
} Float;

void printIEEE_Binary(Float number)
{
    printf("%d | ", number.component.sign);
    printBinary(number.component.exponent, 8);
    printf(" | ");
    printBinary(number.component.mantissa, 23);
    printf("\n");
}

// Driver Code
int main()
{

    // Instantiate the union
    Float var;
    float number;
    printf("Decimal input:");
    scanf("%f", &number);
    var.f = number;
    printf("Decimal to Binary in IEEE 754 :");
    printIEEE_Binary(var);
   
    return 0;
}